import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';

import { environment } from '../../../environments/environment';

interface RagCitation { document: string; section?: string; score?: number; }
interface RagResponse {
  query: string;
  answer: string;
  citations: RagCitation[];
  provider: string;
  model: string;
  prompt_version: string;
  context?: Record<string, unknown>;
}

@Component({
  standalone: true,
  selector: 'app-ask',
  imports: [CommonModule, FormsModule, MatButtonModule,
            MatFormFieldModule, MatInputModule, MatIconModule],
  template: `
    <h1 style="margin:0 0 8px 0;">Ask AI</h1>
    <p style="color:#64748b;">
      Ask a compliance-knowledge question. Answers cite the demo SOC 2 corpus
      chunks retrieved from Qdrant. AI answers are advisory — always confirm
      with your auditor and internal policies.
    </p>

    <div class="card">
      <div class="row" style="align-items:end;">
        <mat-form-field appearance="outline" style="flex:1;">
          <mat-label>Question</mat-label>
          <input matInput [(ngModel)]="question"
                 placeholder="e.g. What evidence proves periodic access review?">
        </mat-form-field>
        <button mat-flat-button color="primary" (click)="ask()" [disabled]="!question.trim() || loading()">
          <mat-icon>psychology</mat-icon>
          {{ loading() ? 'Thinking…' : 'Ask' }}
        </button>
      </div>
    </div>

    <div class="card" *ngIf="answer() as r">
      <div style="color:#64748b;font-size:12px;text-transform:uppercase;">Answer</div>
      <p style="margin:8px 0 12px 0;line-height:1.5;">{{ r.answer }}</p>
      <div style="color:#64748b;font-size:12px;text-transform:uppercase;">Citations</div>
      <ul style="margin:4px 0 0 0;padding-left:20px;">
        <li *ngFor="let c of r.citations">
          {{ c.document }} <span style="color:#64748b;" *ngIf="c.section">· {{ c.section }}</span>
          <span style="color:#64748b;" *ngIf="c.score !== undefined">· score {{ c.score }}</span>
        </li>
      </ul>
      <div style="color:#64748b;font-size:12px;margin-top:12px;">
        {{ r.provider }} · {{ r.model }} · prompt {{ r.prompt_version }}
      </div>
    </div>

    <div *ngIf="err()" style="color:#dc2626;margin-top:12px;">{{ err() }}</div>
  `,
})
export class AskComponent {
  private readonly http = inject(HttpClient);

  question = 'What evidence proves periodic access review?';
  loading = signal(false);
  answer = signal<RagResponse | null>(null);
  err = signal<string | null>(null);

  ask(): void {
    if (!this.question.trim()) return;
    this.loading.set(true); this.err.set(null); this.answer.set(null);
    this.http.post<RagResponse>(`${environment.apiBase}/rag/query`,
        { query: this.question, framework: 'SOC2', topK: 4 })
      .subscribe({
        next: (r) => this.answer.set(r),
        error: (e) => this.err.set(e?.error?.message ?? 'AI service failed'),
        complete: () => this.loading.set(false),
      });
  }
}
