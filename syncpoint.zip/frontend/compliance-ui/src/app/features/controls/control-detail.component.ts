import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';

import { ApiService } from '../../core/api/api.service';
import { Control, Evidence } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-control-detail',
  imports: [CommonModule, RouterLink, MatButtonModule, MatCardModule],
  template: `
    <div style="margin-bottom:12px;"><a routerLink="/controls">← All controls</a></div>
    <ng-container *ngIf="control() as c">
      <div class="card">
        <div class="row" style="align-items:flex-start;">
          <div style="flex:1;">
            <h1 style="margin:0 0 6px 0;">{{ c.code }} — {{ c.title }}</h1>
            <div style="color:#64748b;font-size:13px;">Framework: {{ c.frameworkCode }} · Category: {{ c.category }}</div>
          </div>
          <span class="badge" [class]="statusClass(c.status)" style="font-size:14px;padding:6px 14px;">{{ c.status }}</span>
        </div>
        <p style="margin-top:16px;line-height:1.5;">{{ c.description }}</p>
      </div>

      <div class="card">
        <h2 style="margin:0 0 12px 0;">Mapped evidence</h2>
        <table style="width:100%;border-collapse:collapse;" *ngIf="evidence().length; else empty">
          <thead style="color:#64748b;font-size:12px;text-transform:uppercase;">
            <tr><th style="text-align:left;padding:8px;">Name</th>
                <th style="text-align:left;padding:8px;">Source</th>
                <th style="text-align:left;padding:8px;">Status</th>
                <th style="text-align:left;padding:8px;">Collected</th></tr>
          </thead>
          <tbody>
            <tr *ngFor="let e of evidence()" style="border-top:1px solid #e2e8f0;">
              <td style="padding:10px 8px;">{{ e.name }}</td>
              <td style="padding:10px 8px;">{{ e.sourceType }}</td>
              <td style="padding:10px 8px;">{{ e.status }}</td>
              <td style="padding:10px 8px;">{{ e.collectedAt | date:'short' }}</td>
            </tr>
          </tbody>
        </table>
        <ng-template #empty>
          <p style="color:#64748b;">No evidence mapped to this control yet. Upload evidence and map it, or run an AI analysis.</p>
        </ng-template>
      </div>
    </ng-container>
  `,
})
export class ControlDetailComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly api = inject(ApiService);

  control = signal<Control | null>(null);
  evidence = signal<Evidence[]>([]);

  ngOnInit(): void {
    this.route.paramMap.subscribe(pm => {
      const id = pm.get('id');
      if (!id) return;
      this.api.control(id).subscribe(c => this.control.set(c));
      this.api.controlEvidence(id).subscribe(e => this.evidence.set(e));
    });
  }

  statusClass(s: string): string {
    return { COVERED: 'covered', PARTIAL: 'partial',
             MISSING: 'missing', NEEDS_REVIEW: 'needs-review' }[s] ?? '';
  }
}
