import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

import { ApiService } from '../../core/api/api.service';
import { Control } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-controls',
  imports: [CommonModule, RouterLink, FormsModule, MatFormFieldModule, MatInputModule, MatSelectModule],
  styles: [`
    table { width: 100%; border-collapse: collapse; }
    th, td { text-align: left; padding: 10px 8px; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
    th { color: #64748b; font-weight: 500; font-size: 12px; text-transform: uppercase; }
    .filters { display: flex; gap: 12px; align-items: end; margin-bottom: 16px; }
  `],
  template: `
    <h1 style="margin:0 0 16px 0;">Controls</h1>
    <div class="card">
      <div class="filters">
        <mat-form-field appearance="outline" style="flex:1;">
          <mat-label>Search</mat-label>
          <input matInput [(ngModel)]="search" placeholder="Code, title, category">
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Status</mat-label>
          <mat-select [(ngModel)]="statusFilter">
            <mat-option value="">All</mat-option>
            <mat-option value="COVERED">Covered</mat-option>
            <mat-option value="PARTIAL">Partial</mat-option>
            <mat-option value="MISSING">Missing</mat-option>
            <mat-option value="NEEDS_REVIEW">Needs Review</mat-option>
          </mat-select>
        </mat-form-field>
      </div>
      <table>
        <thead>
          <tr>
            <th>Code</th><th>Title</th><th>Category</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let c of filtered()">
            <td><a [routerLink]="['/controls', c.id]">{{ c.code }}</a></td>
            <td>{{ c.title }}</td>
            <td>{{ c.category }}</td>
            <td><span class="badge" [class]="statusClass(c.status)">{{ c.status }}</span></td>
          </tr>
        </tbody>
      </table>
      <p *ngIf="!filtered().length" style="color:#64748b;">No controls match your filter.</p>
    </div>
  `,
})
export class ControlsComponent implements OnInit {
  private readonly api = inject(ApiService);

  all = signal<Control[]>([]);
  search = '';
  statusFilter = '';

  filtered = computed(() => {
    const q = this.search.toLowerCase().trim();
    const s = this.statusFilter;
    return this.all().filter(c => {
      if (s && c.status !== s) return false;
      if (!q) return true;
      return c.code.toLowerCase().includes(q)
          || c.title.toLowerCase().includes(q)
          || c.category.toLowerCase().includes(q);
    });
  });

  ngOnInit(): void {
    this.api.controls().subscribe(cs => this.all.set(cs));
  }

  statusClass(s: string): string {
    return { COVERED: 'covered', PARTIAL: 'partial',
             MISSING: 'missing', NEEDS_REVIEW: 'needs-review' }[s] ?? '';
  }
}
