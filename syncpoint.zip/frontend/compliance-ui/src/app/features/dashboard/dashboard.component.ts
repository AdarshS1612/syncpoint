import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

import { ApiService } from '../../core/api/api.service';
import { ControlGap, DashboardSummary, Evidence } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [CommonModule, RouterLink, MatIconModule],
  styles: [`
    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 20px; }
    .stat h1 { margin: 4px 0; font-size: 28px; color: #0f172a; }
    .stat span { color: #64748b; font-size: 13px; }
    .stat .value.large { font-size: 40px; font-weight: 700; }
    .bar { height: 10px; background: #e2e8f0; border-radius: 999px; overflow: hidden; margin-top: 6px; }
    .bar > div { height: 100%; background: linear-gradient(90deg, #22c55e, #3b82f6); }
    table { width: 100%; border-collapse: collapse; }
    th, td { text-align: left; padding: 10px 8px; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
    th { color: #64748b; font-weight: 500; font-size: 12px; text-transform: uppercase; }
  `],
  template: `
    <h1 style="margin:0 0 16px 0;">SOC 2 Evidence Readiness</h1>

    <div class="grid" *ngIf="summary() as s">
      <div class="card stat">
        <span>Overall coverage</span>
        <div class="value large">{{ s.coveragePercent }}%</div>
        <div class="bar"><div [style.width.%]="s.coveragePercent"></div></div>
      </div>
      <div class="card stat">
        <span>Covered</span><h1 class="status-covered">{{ s.byStatus.COVERED }}</h1>
      </div>
      <div class="card stat">
        <span>Partial</span><h1 class="status-partial">{{ s.byStatus.PARTIAL }}</h1>
      </div>
      <div class="card stat">
        <span>Missing / Review</span>
        <h1><span class="status-missing">{{ s.byStatus.MISSING }}</span>
            /
            <span class="status-needs-review">{{ s.byStatus.NEEDS_REVIEW }}</span></h1>
      </div>
    </div>

    <div class="card">
      <div class="row">
        <h2 style="margin:0;">Recent evidence</h2>
        <div class="spacer"></div>
        <a routerLink="/evidence">See all</a>
      </div>
      <table style="margin-top:12px;" *ngIf="recent().length; else emptyEv">
        <thead><tr><th>Name</th><th>Source</th><th>Freshness</th><th>Collected</th></tr></thead>
        <tbody>
          <tr *ngFor="let e of recent()">
            <td>{{ e.name }}</td>
            <td>{{ e.sourceType }}</td>
            <td><span class="badge" [class]="freshnessClass(e.freshness)">{{ e.freshness }}</span></td>
            <td>{{ e.collectedAt | date:'short' }}</td>
          </tr>
        </tbody>
      </table>
      <ng-template #emptyEv><p style="color:#64748b;">No evidence yet — upload one from the Evidence page or connect an integration.</p></ng-template>
    </div>

    <div class="card">
      <div class="row">
        <h2 style="margin:0;">Evidence gaps</h2>
        <div class="spacer"></div>
        <a routerLink="/controls">Review controls</a>
      </div>
      <table style="margin-top:12px;" *ngIf="gaps().length; else emptyG">
        <thead><tr><th>Control</th><th>Title</th><th>Category</th><th>Status</th></tr></thead>
        <tbody>
          <tr *ngFor="let g of gaps() | slice:0:8">
            <td><a [routerLink]="['/controls', g.controlId]">{{ g.code }}</a></td>
            <td>{{ g.title }}</td>
            <td>{{ g.category }}</td>
            <td><span class="badge" [class]="statusClass(g.status)">{{ g.status }}</span></td>
          </tr>
        </tbody>
      </table>
      <ng-template #emptyG><p style="color:#64748b;">All controls covered. Nice.</p></ng-template>
    </div>
  `,
})
export class DashboardComponent implements OnInit {
  private readonly api = inject(ApiService);

  summary = signal<DashboardSummary | null>(null);
  gaps = signal<ControlGap[]>([]);
  recent = signal<Evidence[]>([]);

  ngOnInit(): void {
    this.api.summary().subscribe(s => this.summary.set(s));
    this.api.gaps().subscribe(g => this.gaps.set(g));
    this.api.recentEvidence().subscribe(e => this.recent.set(e));
  }

  statusClass(s: string): string {
    return {
      COVERED: 'covered', PARTIAL: 'partial',
      MISSING: 'missing', NEEDS_REVIEW: 'needs-review',
    }[s] ?? '';
  }
  freshnessClass(s: string): string {
    return { CURRENT: 'covered', EXPIRING: 'partial', EXPIRED: 'missing' }[s] ?? '';
  }
}
