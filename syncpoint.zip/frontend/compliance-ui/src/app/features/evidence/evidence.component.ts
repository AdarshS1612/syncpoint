import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';

import { ApiService } from '../../core/api/api.service';
import { Control, Evidence } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-evidence',
  imports: [CommonModule, FormsModule, MatButtonModule, MatCardModule,
            MatFormFieldModule, MatInputModule, MatSelectModule, MatIconModule],
  template: `
    <h1 style="margin:0 0 16px 0;">Evidence</h1>

    <div class="card">
      <h2 style="margin:0 0 12px 0;">Upload manual evidence</h2>
      <div class="row" style="align-items:end;">
        <mat-form-field appearance="outline" style="flex:1;">
          <mat-label>Name</mat-label>
          <input matInput [(ngModel)]="name">
        </mat-form-field>
        <input #f type="file" (change)="fileChanged(f.files)" style="display:none;">
        <button mat-stroked-button (click)="f.click()">
          <mat-icon>upload</mat-icon>
          {{ file ? file.name : 'Choose file' }}
        </button>
        <button mat-flat-button color="primary" (click)="upload()" [disabled]="!file || uploading()">
          {{ uploading() ? 'Uploading…' : 'Upload' }}
        </button>
      </div>
      <div *ngIf="uploadError()" style="color:#dc2626;font-size:13px;margin-top:8px;">{{ uploadError() }}</div>
    </div>

    <div class="card">
      <h2 style="margin:0 0 12px 0;">All evidence</h2>
      <table style="width:100%;border-collapse:collapse;" *ngIf="items().length; else empty">
        <thead style="color:#64748b;font-size:12px;text-transform:uppercase;">
          <tr>
            <th style="text-align:left;padding:8px;">Name</th>
            <th style="text-align:left;padding:8px;">Source</th>
            <th style="text-align:left;padding:8px;">Status</th>
            <th style="text-align:left;padding:8px;">Freshness</th>
            <th style="text-align:left;padding:8px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let e of items()" style="border-top:1px solid #e2e8f0;">
            <td style="padding:10px 8px;">{{ e.name }}</td>
            <td style="padding:10px 8px;">{{ e.sourceType }}</td>
            <td style="padding:10px 8px;">{{ e.status }}</td>
            <td style="padding:10px 8px;">
              <span class="badge" [class]="freshnessClass(e.freshness)">{{ e.freshness }}</span>
            </td>
            <td style="padding:10px 8px;">
              <mat-form-field appearance="outline" style="width:160px;">
                <mat-label>Map to</mat-label>
                <mat-select [(ngModel)]="selectedControl[e.id]">
                  <mat-option *ngFor="let c of controls()" [value]="c.id">{{ c.code }} — {{ c.title }}</mat-option>
                </mat-select>
              </mat-form-field>
              <button mat-stroked-button (click)="map(e.id)" [disabled]="!selectedControl[e.id]">Confirm</button>
              <button mat-stroked-button (click)="analyze(e.id)"
                      [disabled]="!selectedControl[e.id] || analyzing()[e.id]"
                      style="margin-left:6px;">
                {{ analyzing()[e.id] ? '…' : 'AI analyze' }}
              </button>
              <button mat-stroked-button (click)="approve(e.id)" style="margin-left:6px;">Approve</button>
            </td>
          </tr>
        </tbody>
      </table>
      <ng-template #empty><p style="color:#64748b;">No evidence yet.</p></ng-template>
      <div *ngIf="msg()" style="color:#166534;font-size:13px;margin-top:8px;">{{ msg() }}</div>
    </div>
  `,
})
export class EvidenceComponent implements OnInit {
  private readonly api = inject(ApiService);

  items = signal<Evidence[]>([]);
  controls = signal<Control[]>([]);
  name = '';
  file: File | null = null;
  uploading = signal(false);
  uploadError = signal<string | null>(null);
  analyzing = signal<Record<string, boolean>>({});
  msg = signal<string | null>(null);
  selectedControl: Record<string, string> = {};

  ngOnInit(): void {
    this.reload();
    this.api.controls().subscribe(cs => this.controls.set(cs));
  }

  fileChanged(files: FileList | null): void {
    this.file = files && files.length ? files[0] : null;
    if (this.file && !this.name) this.name = this.file.name;
  }

  upload(): void {
    if (!this.file) return;
    const form = new FormData();
    if (this.name) form.append('name', this.name);
    form.append('file', this.file);
    this.uploading.set(true);
    this.uploadError.set(null);
    this.api.uploadEvidence(form).subscribe({
      next: () => { this.name = ''; this.file = null; this.reload(); },
      error: (e) => this.uploadError.set(e?.error?.message ?? 'Upload failed'),
      complete: () => this.uploading.set(false),
    });
  }

  map(evidenceId: string): void {
    const controlId = this.selectedControl[evidenceId];
    if (!controlId) return;
    this.api.createMapping(evidenceId, {
      controlId, mappingType: 'HUMAN_CONFIRMED',
      classification: 'COVERED', confidence: 1, reason: 'Reviewer confirmed.',
    }).subscribe(() => { this.msg.set('Mapping saved.'); this.reload(); });
  }

  analyze(evidenceId: string): void {
    const controlId = this.selectedControl[evidenceId];
    if (!controlId) return;
    this.analyzing.update(x => ({ ...x, [evidenceId]: true }));
    this.api.analyzeEvidence(evidenceId, { controlId }).subscribe({
      next: (r) => {
        this.msg.set(`AI: ${r['classification']} (${r['provider']} · ${r['model']})`);
        this.reload();
      },
      complete: () => this.analyzing.update(x => ({ ...x, [evidenceId]: false })),
    });
  }

  approve(evidenceId: string): void {
    this.api.reviewEvidence(evidenceId, { decision: 'APPROVED', comments: 'OK' })
      .subscribe(() => { this.msg.set('Evidence approved.'); this.reload(); });
  }

  freshnessClass(s: string): string {
    return { CURRENT: 'covered', EXPIRING: 'partial', EXPIRED: 'missing' }[s] ?? '';
  }

  private reload(): void {
    this.api.evidence().subscribe(list => this.items.set(list));
  }
}
