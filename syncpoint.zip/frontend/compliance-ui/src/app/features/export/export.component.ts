import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { Subscription, timer } from 'rxjs';

import { ApiService } from '../../core/api/api.service';
import { ExportJob } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-export',
  imports: [CommonModule, MatButtonModule, MatIconModule],
  template: `
    <h1 style="margin:0 0 16px 0;">Audit package</h1>

    <div class="card">
      <p>
        Package your organization's evidence, control mappings and evidence hashes into a
        downloadable ZIP for internal review or a first conversation with an auditor.
        <br><b>Note:</b> Syncpoint does not determine SOC 2 compliance. This is an
        evidence package — not a certification.
      </p>
      <div class="row" style="margin-top:12px;">
        <button mat-flat-button color="primary" (click)="start()" [disabled]="starting()">
          <mat-icon>inventory_2</mat-icon>
          {{ starting() ? 'Building…' : 'Generate audit package' }}
        </button>
      </div>
    </div>

    <div class="card" *ngIf="job() as j">
      <h2 style="margin:0 0 8px 0;">Latest export</h2>
      <div class="row">
        <span>Status:</span>
        <span class="badge" [class]="jobBadge(j.status)">{{ j.status }}</span>
        <div class="spacer"></div>
        <a *ngIf="j.status === 'COMPLETED'" [href]="downloadUrl(j.id)"
           download="syncpoint-audit-package.zip" class="mat-mdc-button mdc-button">
          <mat-icon style="vertical-align:middle;">download</mat-icon>
          Download ({{ j.sizeBytes | number }} bytes)
        </a>
      </div>
      <div *ngIf="j.errorMessage" style="color:#dc2626;font-size:13px;">{{ j.errorMessage }}</div>
    </div>
  `,
})
export class ExportComponent implements OnInit {
  private readonly api = inject(ApiService);

  starting = signal(false);
  job = signal<ExportJob | null>(null);
  private poll?: Subscription;

  ngOnInit(): void {}

  start(): void {
    this.starting.set(true);
    this.api.startExport().subscribe({
      next: (j) => {
        this.job.set(j);
        this.pollUntilDone(j.id);
      },
      complete: () => this.starting.set(false),
    });
  }

  private pollUntilDone(id: string): void {
    this.poll?.unsubscribe();
    this.poll = timer(0, 2000).subscribe(() => {
      this.api.exportStatus(id).subscribe(j => {
        this.job.set(j);
        if (j.status === 'COMPLETED' || j.status === 'FAILED') this.poll?.unsubscribe();
      });
    });
  }

  jobBadge(s: string): string {
    return { COMPLETED: 'covered', RUNNING: 'partial', QUEUED: 'pending', FAILED: 'error' }[s] ?? '';
  }
  downloadUrl(id: string): string { return this.api.exportDownloadUrl(id); }
}
