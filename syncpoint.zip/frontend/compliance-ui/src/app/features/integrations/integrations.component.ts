import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';

import { ApiService } from '../../core/api/api.service';
import { Integration } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-integrations',
  imports: [CommonModule, FormsModule, MatButtonModule,
            MatFormFieldModule, MatInputModule, MatIconModule],
  styles: [`
    .provider { display:flex; align-items:center; gap: 12px; }
    .provider mat-icon { font-size: 28px; height: 28px; width: 28px; color: #0f172a; }
    .provider-tile { padding: 16px; border: 1px solid #e2e8f0; border-radius: 10px; background: white; }
    .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    @media (max-width: 900px) { .grid2 { grid-template-columns: 1fr; } }
    .muted { color: #64748b; font-size: 13px; }
  `],
  template: `
    <h1 style="margin:0 0 16px 0;">Integrations</h1>

    <div class="card">
      <h2 style="margin:0 0 12px 0;">Connect GitHub</h2>
      <p class="muted">Paste a fine-grained Personal Access Token with <code>read:org</code>,
        <code>repo</code> and <code>read:user</code> scopes. The token is encrypted and stored
        as a secret reference — it is never returned in an API response.</p>
      <div class="row" style="align-items:end;">
        <mat-form-field appearance="outline" style="flex:1;">
          <mat-label>Display name</mat-label>
          <input matInput [(ngModel)]="displayName" placeholder="Company GitHub">
        </mat-form-field>
        <mat-form-field appearance="outline" style="flex:2;">
          <mat-label>GitHub PAT</mat-label>
          <input matInput type="password" [(ngModel)]="token" placeholder="github_pat_...">
        </mat-form-field>
        <button mat-flat-button color="primary" (click)="connect()" [disabled]="!token || connecting()">
          {{ connecting() ? 'Connecting…' : 'Connect' }}
        </button>
      </div>
      <div *ngIf="msg()" style="color:#166534;font-size:13px;margin-top:8px;">{{ msg() }}</div>
      <div *ngIf="err()" style="color:#dc2626;font-size:13px;margin-top:8px;">{{ err() }}</div>
    </div>

    <div class="card">
      <h2 style="margin:0 0 12px 0;">Your integrations</h2>
      <div *ngIf="items().length; else empty">
        <div *ngFor="let i of items()" class="provider-tile" style="margin-bottom:12px;">
          <div class="row">
            <div class="provider">
              <mat-icon>{{ providerIcon(i.provider) }}</mat-icon>
              <div>
                <div style="font-weight:600;">{{ i.displayName ?? i.provider }}</div>
                <div class="muted">
                  {{ i.provider }} ·
                  <span class="badge" [class]="statusClass(i.status)">{{ i.status }}</span>
                  <span *ngIf="i.lastCollectionAt"> · last collected {{ i.lastCollectionAt | date:'short' }}</span>
                </div>
                <div *ngIf="i.lastTestMessage" class="muted" style="margin-top:4px;">{{ i.lastTestMessage }}</div>
              </div>
            </div>
            <div class="spacer"></div>
            <button mat-stroked-button (click)="test(i.id)">Test</button>
            <button mat-stroked-button (click)="collect(i.id)" style="margin-left:8px;">Collect now</button>
            <button mat-stroked-button color="warn" (click)="disconnect(i.id)" style="margin-left:8px;">Disconnect</button>
          </div>
        </div>
      </div>
      <ng-template #empty><p class="muted">No integrations yet.</p></ng-template>
    </div>

    <div class="card">
      <h2 style="margin:0 0 12px 0;">Coming soon</h2>
      <div class="grid2">
        <div class="provider-tile"><div class="provider"><mat-icon>cloud</mat-icon><div><b>AWS</b><div class="muted">Cross-account IAM role — future release</div></div></div></div>
        <div class="provider-tile"><div class="provider"><mat-icon>bug_report</mat-icon><div><b>Jira</b><div class="muted">OAuth — future release</div></div></div></div>
        <div class="provider-tile"><div class="provider"><mat-icon>groups</mat-icon><div><b>Google Workspace</b><div class="muted">OAuth — future release</div></div></div></div>
      </div>
    </div>
  `,
})
export class IntegrationsComponent implements OnInit {
  private readonly api = inject(ApiService);

  items = signal<Integration[]>([]);
  token = '';
  displayName = '';
  connecting = signal(false);
  msg = signal<string | null>(null);
  err = signal<string | null>(null);

  ngOnInit(): void { this.reload(); }

  connect(): void {
    this.connecting.set(true);
    this.msg.set(null); this.err.set(null);
    this.api.connectGitHub({ token: this.token, displayName: this.displayName || undefined }).subscribe({
      next: (i) => {
        this.msg.set(`Connected: ${i.lastTestMessage ?? i.status}`);
        this.token = ''; this.displayName = '';
        this.reload();
      },
      error: (e) => this.err.set(e?.error?.message ?? 'Connection failed'),
      complete: () => this.connecting.set(false),
    });
  }

  test(id: string): void {
    this.api.testIntegration(id).subscribe(r =>
      this.msg.set(r.ok ? `OK — ${r.message}` : `Failed — ${r.message}`));
  }
  collect(id: string): void {
    this.api.collectIntegration(id).subscribe(r =>
      this.msg.set(`Collection queued: ${r.collectionRunId}`));
  }
  disconnect(id: string): void {
    this.api.disconnectIntegration(id).subscribe(() => { this.msg.set('Disconnected.'); this.reload(); });
  }

  providerIcon(p: string): string {
    return { GITHUB: 'code', AWS: 'cloud', JIRA: 'bug_report', GOOGLE_WORKSPACE: 'groups' }[p] ?? 'hub';
  }
  statusClass(s: string): string {
    return { CONNECTED: 'connected', PENDING: 'pending', ERROR: 'error', DISCONNECTED: 'disconnected' }[s] ?? '';
  }

  private reload(): void {
    this.api.integrations().subscribe(list => this.items.set(list));
  }
}
