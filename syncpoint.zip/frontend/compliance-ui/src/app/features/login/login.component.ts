import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

import { ApiService } from '../../core/api/api.service';
import { TokenStore } from '../../core/auth/token-store.service';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [CommonModule, FormsModule, RouterLink,
            MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
    <div style="min-height:100vh;display:grid;place-items:center;padding:24px;">
      <mat-card style="width:100%;max-width:400px;padding:24px;">
        <h1 style="margin:0 0 4px 0;font-size:22px;">Sign in</h1>
        <p style="margin:0 0 20px 0;color:#64748b;">Syncpoint Compliance</p>
        <form (ngSubmit)="submit()" class="stack">
          <mat-form-field appearance="outline">
            <mat-label>Email</mat-label>
            <input matInput type="email" name="email" [(ngModel)]="email" required autocomplete="username">
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Password</mat-label>
            <input matInput type="password" name="password" [(ngModel)]="password" required autocomplete="current-password">
          </mat-form-field>
          <button mat-flat-button color="primary" type="submit" [disabled]="loading()">
            {{ loading() ? 'Signing in…' : 'Sign in' }}
          </button>
          <div *ngIf="error()" style="color:#dc2626;font-size:13px;">{{ error() }}</div>
        </form>
        <p style="margin-top:16px;font-size:13px;color:#64748b;">
          New here? <a routerLink="/register">Create an organization</a>
        </p>
      </mat-card>
    </div>
  `,
})
export class LoginComponent {
  private readonly api = inject(ApiService);
  private readonly store = inject(TokenStore);
  private readonly router = inject(Router);

  email = '';
  password = '';
  loading = signal(false);
  error = signal<string | null>(null);

  submit(): void {
    this.error.set(null);
    this.loading.set(true);
    this.api.login({ email: this.email, password: this.password }).subscribe({
      next: (t) => {
        this.store.setTokens(t.accessToken, t.refreshToken);
        this.router.navigateByUrl('/dashboard');
      },
      error: (e) => {
        this.loading.set(false);
        this.error.set(e?.error?.message ?? 'Sign in failed');
      },
      complete: () => this.loading.set(false),
    });
  }
}
