import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { ApiService } from '../../core/api/api.service';
import { Framework } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-onboarding',
  imports: [CommonModule, RouterLink, MatButtonModule, MatIconModule],
  template: `
    <h1 style="margin:0 0 8px 0;">Welcome to Syncpoint Compliance</h1>
    <p style="color:#64748b;">Let's get you to your first evidence result.</p>

    <div class="card">
      <div class="row">
        <mat-icon>looks_one</mat-icon>
        <div><b>Select a framework</b><br>
          <span *ngIf="framework() as f">{{ f.name }} ({{ f.version }}) is already active for your org.</span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="row">
        <mat-icon>looks_two</mat-icon>
        <div><b>Connect your first system</b><br>
          <span style="color:#64748b;">Start with GitHub — paste a PAT and Syncpoint will pull org / repo / branch-protection evidence.</span>
        </div>
        <div class="spacer"></div>
        <button mat-flat-button color="primary" routerLink="/integrations">Connect GitHub</button>
      </div>
    </div>

    <div class="card">
      <div class="row">
        <mat-icon>looks_3</mat-icon>
        <div><b>Upload manual evidence</b><br>
          <span style="color:#64748b;">Any PDF, CSV, JSON, DOCX or XLSX up to 50MB.</span>
        </div>
        <div class="spacer"></div>
        <button mat-stroked-button routerLink="/evidence">Go to Evidence</button>
      </div>
    </div>

    <div class="card">
      <div class="row">
        <mat-icon>looks_4</mat-icon>
        <div><b>Ask AI to map evidence to controls</b><br>
          <span style="color:#64748b;">Suggestions land as <code>AI_SUGGESTED</code> mappings that require human review.</span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="row">
        <mat-icon>looks_5</mat-icon>
        <div><b>Watch your coverage grow</b><br>
          <span style="color:#64748b;">The dashboard tracks Covered / Partial / Missing / Needs Review.</span>
        </div>
        <div class="spacer"></div>
        <button mat-stroked-button routerLink="/dashboard">Open dashboard</button>
      </div>
    </div>
  `,
})
export class OnboardingComponent implements OnInit {
  private readonly api = inject(ApiService);

  framework = signal<Framework | null>(null);

  ngOnInit(): void {
    this.api.frameworks().subscribe(fs => this.framework.set(fs[0] ?? null));
  }
}
