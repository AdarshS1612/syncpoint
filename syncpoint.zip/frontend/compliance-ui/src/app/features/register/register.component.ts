import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

import { ApiService } from '../../core/api/api.service';
import { TokenStore } from '../../core/auth/token-store.service';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [CommonModule, FormsModule, RouterLink,
            MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
    <div style="min-height:100vh;display:grid;place-items:center;padding:24px;">
      <mat-card style="width:100%;max-width:440px;padding:24px;">
        <h1 style="margin:0 0 4px 0;font-size:22px;">Create your organization</h1>
        <p style="margin:0 0 20px 0;color:#64748b;">The first user becomes the OWNER.</p>
        <form (ngSubmit)="submit()" class="stack">
          <mat-form-field appearance="outline">
            <mat-label>Full name</mat-label>
            <input matInput name="name" [(ngModel)]="name" required autocomplete="name">
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Work email</mat-label>
            <input matInput type="email" name="email" [(ngModel)]="email" required autocomplete="email">
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Password (min 12 chars)</mat-label>
            <input matInput type="password" name="password" [(ngModel)]="password" minlength="12" required autocomplete="new-password">
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Organization name</mat-label>
            <input matInput name="org" [(ngModel)]="organizationName" required>
          </mat-form-field>
          <button mat-flat-button color="primary" type="submit" [disabled]="loading()">
            {{ loading() ? 'Creating…' : 'Create organization' }}
          </button>
          <div *ngIf="error()" style="color:#dc2626;font-size:13px;">{{ error() }}</div>
        </form>
        <p style="margin-top:16px;font-size:13px;color:#64748b;">
          Already have an account? <a routerLink="/login">Sign in</a>
        </p>
      </mat-card>
    </div>
  `,
})
export class RegisterComponent {
  private readonly api = inject(ApiService);
  private readonly store = inject(TokenStore);
  private readonly router = inject(Router);

  name = '';
  email = '';
  password = '';
  organizationName = '';
  loading = signal(false);
  error = signal<string | null>(null);

  submit(): void {
    this.error.set(null);
    this.loading.set(true);
    this.api.register({
      email: this.email, password: this.password,
      name: this.name, organizationName: this.organizationName,
    }).subscribe({
      next: (t) => {
        this.store.setTokens(t.accessToken, t.refreshToken);
        this.router.navigateByUrl('/onboarding');
      },
      error: (e) => {
        this.loading.set(false);
        this.error.set(e?.error?.message ?? 'Registration failed');
      },
      complete: () => this.loading.set(false),
    });
  }
}
