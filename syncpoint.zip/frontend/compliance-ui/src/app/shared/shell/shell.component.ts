import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

import { ApiService } from '../../core/api/api.service';
import { TokenStore } from '../../core/auth/token-store.service';
import { Me } from '../../core/api/api.types';

@Component({
  standalone: true,
  selector: 'app-shell',
  imports: [CommonModule, RouterOutlet, RouterLink, MatIconModule, MatButtonModule],
  styles: [`
    :host { display: block; min-height: 100vh; }
    .shell { display: grid; grid-template-columns: 240px 1fr; min-height: 100vh; }
    .side {
      background: #0f172a; color: #cbd5e1; padding: 20px 12px;
      display: flex; flex-direction: column; gap: 4px;
    }
    .brand { color: white; font-weight: 700; font-size: 18px; margin: 0 8px 20px 8px; }
    .link {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 12px; border-radius: 8px; color: #cbd5e1;
      text-decoration: none; font-size: 14px;
    }
    .link mat-icon { font-size: 18px; height: 18px; width: 18px; }
    .link.active, .link:hover { background: #1e293b; color: white; }
    .main { display: flex; flex-direction: column; }
    header {
      background: white; padding: 12px 24px; border-bottom: 1px solid #e2e8f0;
      display: flex; align-items: center;
    }
    header .who { color: #64748b; font-size: 13px; margin-right: 12px; }
    .content { padding: 24px; }
  `],
  template: `
    <div class="shell">
      <aside class="side">
        <div class="brand">Syncpoint</div>
        <a class="link" routerLink="/dashboard" routerLinkActive="active"><mat-icon>dashboard</mat-icon>Dashboard</a>
        <a class="link" routerLink="/controls" routerLinkActive="active"><mat-icon>fact_check</mat-icon>Controls</a>
        <a class="link" routerLink="/evidence" routerLinkActive="active"><mat-icon>description</mat-icon>Evidence</a>
        <a class="link" routerLink="/integrations" routerLinkActive="active"><mat-icon>hub</mat-icon>Integrations</a>
        <a class="link" routerLink="/ask" routerLinkActive="active"><mat-icon>psychology</mat-icon>Ask AI</a>
        <a class="link" routerLink="/audit-package" routerLinkActive="active"><mat-icon>inventory_2</mat-icon>Audit Package</a>
        <a class="link" routerLink="/onboarding" routerLinkActive="active"><mat-icon>rocket_launch</mat-icon>Onboarding</a>
      </aside>
      <section class="main">
        <header>
          <div class="spacer" style="flex:1"></div>
          <div class="who" *ngIf="me() as m">{{ m.name }} · {{ m.organizationName }} · {{ m.role }}</div>
          <button mat-stroked-button (click)="logout()">Sign out</button>
        </header>
        <div class="content"><router-outlet /></div>
      </section>
    </div>
  `,
})
export class ShellComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly store = inject(TokenStore);
  private readonly router = inject(Router);

  me = signal<Me | null>(null);

  ngOnInit(): void {
    this.api.me().subscribe({ next: (m) => this.me.set(m) });
  }

  logout(): void {
    this.store.clear();
    this.router.navigateByUrl('/login');
  }
}
